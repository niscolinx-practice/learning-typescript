export enum Methods {
    get = 'get',
    post = 'post',
    del = 'delete',
    patch = 'delete',
    put = 'delete'
}