import { MatchReader } from './inheritance/matchReader';

const matchReader = new MatchReader('football.csv')

console.log('the match reader!', matchReader)
