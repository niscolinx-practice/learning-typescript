export const stringToDate = (date) => {
    const stringDate = date.split('/');
    return new Date(parseInt(stringDate[2]), 1 - parseInt(stringDate[1]), parseInt(stringDate[0]));
};
